<?php
    include("connection.php");
    if(isset($_POST['sub'])){

        $name= mysqli_real_escape_string($conn, $_POST['name']);
        $location = mysqli_real_escape_string($conn, $_POST['location']);


        $sql = "SELECT * FROM department WHERE name='$name' AND location='$location'";
       

        $result = mysqli_query($conn, $sql);
        $count_user = mysqli_num_rows($result);
  
                
        if($count_user == 0 ){
                $sql = "INSERT INTO department(name, location) VALUES('$name', '$location')";
                $result = mysqli_query($conn, $sql);

                if($result){
                    echo '<script>
                    alert("DEPARTMENT ADDED!!");
                </script>';
                }
            }
                else{
                if($count_user>0){
                    echo '<script>
                        window.location.href="department1.php";
                        alert("DEPARTMENT Already Exists!!");
                    </script>';
                }
            }   
         } 
?>







<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hogwarts University</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="stylez.css">
    <link rel="stylesheet" href="stylec.css">
</head>

<body>

<div class="header">
<?php include("navtrans.php");
 ?>
        <nav>
            <a href="Admin.php">
            <h1 style="color:azure;">HU</h1>
            <img src="images/hogwartslogo1.png" alt="logo"></a>
            <div class="nav-links">
               
                <ul>
                    <li><a href="course.php">COURSE</a></li>
                    <li><a href="department1.php">DEPERTMENT</a></li>
                    <li><a href="instructor.php">INSTRUCTOR</a></li>
                    <li><a href="register.php">REGISTER</a></li>
                    <li><a href="studentsignup.php">STUDENT</a></li>
                 </ul>
            </div>
            

        </nav>
  </div>

  <div class="view" style="text-align: center;">
  <a href="deptData.php" class="button-link-center big-prominent-button">View Department Info</a>
</div>

  <div id="dform">
        <h1 id="heading"> DEPARTMENT INFO</h1><br>
        <form name="form" action="department1.php" method="POST">

            <label>Dept. Name:     </label>
            <input type="text" id="name" name="name" required><br><br>
            <label>Dept. Location: </label>
            <input type="text" id="location" name="location" required><br><br>
           

            <!--Button-->
            <input type="submit" id="btn" value="SUBMIT" name = "sub"/>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    
   
    
  

</body>
</html>