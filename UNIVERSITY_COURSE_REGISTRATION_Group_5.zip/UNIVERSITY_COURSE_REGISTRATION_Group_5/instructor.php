<?php
    include("connection.php");
    if(isset($_POST['sub'])){

        $Instructor_Code = mysqli_real_escape_string($conn, $_POST['Instructor_Code']);
        $FirstName = mysqli_real_escape_string($conn, $_POST['FirstName']);
        $LastName = mysqli_real_escape_string($conn, $_POST['LastName']);
        
        $Department = mysqli_real_escape_string($conn, $_POST['Department']);
        
        
        $sql = "SELECT * FROM instructor WHERE Instructor_Code='$Instructor_Code'";

        
        $result = mysqli_query($conn, $sql);
        $count_user = mysqli_num_rows($result);


        if($count_user == 0 ){
                $sql = "INSERT INTO instructor(Instructor_Code, FirstName, LastName, Department) VALUES('$Instructor_Code','$FirstName', '$LastName', '$Department')";
                
                $result = mysqli_query($conn, $sql);

                if($result){
                    echo '<script>
                    alert("Instructor Added!!");
                </script>';
            }
        }
        else{
            if($count_user>0){
                echo '<script>
                    window.location.href="instructor.php";
                    alert("Instructor Already Exists!!");
                </script>';
            }
        }   
    }     
    
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hogwarts University</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link rel="stylesheet" href="stylez.css">
    <link rel="stylesheet" href="stylec.css">
</head>

<body>

<div class="header">
<?php include("navtrans.php");
 ?>
        <nav>
            <a href="Admin.php">
            <h1 style="color:azure;">HU</h1>
            <img src="images/hogwartslogo1.png" alt="logo"></a>
            <div class="nav-links">
               
                <ul>
                    <li><a href="course.php">COURSE</a></li>
                    <li><a href="department1.php">DEPERTMENT</a></li>
                    <li><a href="instructor.php">INSTRUCTOR</a></li>
                    <li><a href="register.php">REGISTER</a></li>
                    <li><a href="studentsignup.php">STUDENT</a></li>
                 </ul>
            </div>
            

        </nav>
  </div>
  <div class="view" style="text-align: center;">
  <a href="instructorData.php" class="button-link-center big-prominent-button">View Instructor Info</a>
</div>

  <div id="iform">
        <h1 id="heading">ADD INSTRUCTOR INFO</h1><br>
        <form name="form" action="instructor.php" method="POST">

            <label>Instructor Code: </label>
            <input type="text" id="Instructor_Code" name="Instructor_Code" required><br><br>

            <label>First Name: </label>
            <input type="text" id="FirstName" name="FirstName" required><br><br>
            <label>Last Name: </label>
            <input type="text" id="LastName" name="LastName" required><br><br>
            
            <label>Department: </label>
            <input type="text" id="Department" name="Department" required><br><br>
            

            <!--Button-->
            <input type="submit" id="btn" value="ADD" name = "sub"/>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    


   
     

</body>
</html>