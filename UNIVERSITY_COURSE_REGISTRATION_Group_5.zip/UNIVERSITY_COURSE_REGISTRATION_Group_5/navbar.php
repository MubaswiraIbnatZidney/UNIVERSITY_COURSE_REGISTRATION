<nav class="navbar navbar-expand-lg bg-body-tertiary pt-3">
  <div class="container-fluid">
    <h1><a class="navbar-brand" href="Home.php">Hogwarts University</a></h1>
    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
       
</ul>
    <form class="d-flex" >
        <a class="btn btn-outline-success mx-2" type="submit" href="signup.php">Signup</a>
        <a class="btn btn-outline-primary mx-2" type="submit" href="login.php">Login</a>
        
    </form>
    
  </div>
</nav>