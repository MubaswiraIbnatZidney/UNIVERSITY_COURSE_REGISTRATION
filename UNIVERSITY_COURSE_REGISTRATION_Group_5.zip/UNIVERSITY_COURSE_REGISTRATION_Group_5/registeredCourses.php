<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registered Courses</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styleedit.css">
</head>
<body>
<?php include("navtrans1.php"); ?>

<div class="container mt-5">
<h1 class="text-light">Registered Courses</h1>
 
    <table class="table table-dark">
        <thead class="thead-dark">
   
            <tr>
                <th>Reg_ID</th>
                <th>Status</th>
                <th>Grade</th>
                <th>Date</th>
                <th>Student ID</th>
                <th>Course ID</th>   

            </tr>
        </thead>
        <tbody>
            <?php
            
            $servername = 'localhost';
            $username = 'root';
            $password = '';
            $dbname = 'db';

            //test
            include("connection.php");
            session_start();
    
             if(!isset($_SESSION['loggedin']) || isset($_SESSION['loggedin'])!=true){
             header("location:registeredCourses.php");
            exit;
             }

            $email = $_SESSION['Email'];
            echo $email;
            $Student_ID = "SELECT Student_ID FROM student WHERE Email = '$email'";
            $result = mysqli_query($conn, $Student_ID);
            $row = mysqli_fetch_assoc($result);
            echo $row['Student_ID'];  //KAJ KORSEEEE
            $Std_ID = $row['Student_ID'];

            // Creating a connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Checking the connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetching data from the database
            $sql = "SELECT reg_id, status, grade, date, Student_ID, course_id FROM register where Student_ID='$Std_ID'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                // Outputting data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["reg_id"] . "</td>";
                    echo "<td>" . $row["status"] . "</td>";
                    echo "<td>" . $row["grade"] . "</td>";
                    echo "<td>" . $row["date"] . "</td>";
                    echo "<td>" . $row["Student_ID"] . "</td>";
                    echo "<td>" . $row["course_id"] . "</td>";
                 
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No records found</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</div>



</body>
</html>
